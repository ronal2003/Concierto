public class Main {
    public static void main(String[] args) {
        Menu miMenucito = new Menu();
        miMenucito.menuOpciones();
    }
}
